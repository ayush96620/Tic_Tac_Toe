package com.example.tic_tac_toe;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

public class Windialog extends Dialog {

    private final String message;
    private final gamepage game;

    public Windialog(@NonNull Context context, String message, gamepage game) {
        super(context);
        this.message = message;
        this.game = game;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.win_dialog);

        TextView messageTextView = findViewById(R.id.message);
        Button startAgainButton = findViewById(R.id.startagain);

        messageTextView.setText(this.message);

        startAgainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gamepage.restart();
                dismiss();
            }
        });
    }
}




