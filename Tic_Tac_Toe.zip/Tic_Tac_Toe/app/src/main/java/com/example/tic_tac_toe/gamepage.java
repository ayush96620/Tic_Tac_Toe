package com.example.tic_tac_toe;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class gamepage extends AppCompatActivity {

    List<int[]> combinationlist = new ArrayList<>();
    private static int[] boxposition = {0, 0, 0, 0, 0, 0, 0, 0, 0};
    private static int playerturn = 1;
    private static int totalselectedbox = 1;

    private LinearLayout p1layout, p2layout;
    private TextView player1txt, player2txt;

    private static ImageView img1, img2, img3, img4, img5, img6, img7, img8, img9;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_gamepage);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        p1layout = findViewById(R.id.linear1);
        p2layout = findViewById(R.id.linear2);

        player1txt = findViewById(R.id.txt1);
        player2txt = findViewById(R.id.txt2);

        combinationlist.add(new int[]{0, 1, 2});
        combinationlist.add(new int[]{3, 4, 5});
        combinationlist.add(new int[]{6, 7, 8});
        combinationlist.add(new int[]{0, 3, 6});
        combinationlist.add(new int[]{1, 4, 7});
        combinationlist.add(new int[]{2, 5, 8});
        combinationlist.add(new int[]{0, 4, 8});
        combinationlist.add(new int[]{2, 4, 6});

        img1 = findViewById(R.id.fimg1);
        img2 = findViewById(R.id.fimg2);
        img3 = findViewById(R.id.fimg3);
        img4 = findViewById(R.id.simg1);
        img5 = findViewById(R.id.simg2);
        img6 = findViewById(R.id.simg3);
        img7 = findViewById(R.id.timg1);
        img8 = findViewById(R.id.timg2);
        img9 = findViewById(R.id.timg3);

        ImageView[] imageViews = {img1, img2, img3, img4, img5, img6, img7, img8, img9};

        for (int i = 0; i < imageViews.length; i++) {
            final int index = i;
            imageViews[i].setOnClickListener(view -> {
                if (!isBoxSelected(index)) {
                    performAction((ImageView) view, index);
                }
            });
        }
    }

    private void performAction(ImageView img, int selectedBoxPosition) {
        boxposition[selectedBoxPosition] = playerturn;

        if (playerturn == 1) {
            img.setImageResource(R.drawable.letterx);
            if (checkWinner()) {
                Windialog windialog = new Windialog(this, player1txt.getText().toString() + " has won the match", this);
                windialog.setCancelable(false);
                windialog.show();
            } else if (totalselectedbox == 9) {
                Windialog windialog = new Windialog(this, "It's a draw match", this);
                windialog.setCancelable(false);
                windialog.show();
            } else {
                changeTurn(2);
                totalselectedbox++;
            }
        } else {
            img.setImageResource(R.drawable.lettero);
            if (checkWinner()) {
                Windialog windialog = new Windialog(this, player2txt.getText().toString() + " has won the match", this);
                windialog.setCancelable(false);
                windialog.show();
            } else if (totalselectedbox == 9) {
                Windialog windialog = new Windialog(this, "It's a draw match", this);
                windialog.setCancelable(false);
                windialog.show();
            } else {
                changeTurn(1);
                totalselectedbox++;
            }
        }
    }

    private void changeTurn(int currentPlayerTurn) {
        playerturn = currentPlayerTurn;
        if (playerturn == 1) {
            p2layout.setBackgroundResource(R.drawable.layoutbg);
            p1layout.setBackgroundResource(R.drawable.layoutbg);
        } else {
            p1layout.setBackgroundResource(R.drawable.layoutbg);
            p2layout.setBackgroundResource(R.drawable.layoutbg);
        }
    }

    private boolean checkWinner() {
        for (int[] combination : combinationlist) {
            if (boxposition[combination[0]] == boxposition[combination[1]] &&
                    boxposition[combination[1]] == boxposition[combination[2]] &&
                    boxposition[combination[0]] != 0) {
                return true;
            }
        }
        return false;
    }

    private boolean isBoxSelected(int position) {
        return boxposition[position] != 0;
    }

    public static void restart() {
        boxposition = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
        totalselectedbox = 1;
        playerturn = 1;

        img1.setImageResource(R.drawable.shadow);
        img2.setImageResource(R.drawable.shadow);
        img3.setImageResource(R.drawable.shadow);
        img4.setImageResource(R.drawable.shadow);
        img5.setImageResource(R.drawable.shadow);
        img6.setImageResource(R.drawable.shadow);
        img7.setImageResource(R.drawable.shadow);
        img8.setImageResource(R.drawable.shadow);
        img9.setImageResource(R.drawable.shadow);
    }
}















    //
//    List <int []> combinationlist = new ArrayList<>();
//    private static int[] boxposition = {0,0,0,0,0,0,0,0,0};
//    private static int playerturn = 1;
//    private static int totelselectedbox = 1;
//
//        static ImageView fimg1;
//    static ImageView fimg2;
//    static ImageView fimg3;
//    static ImageView simg1;
//    static ImageView simg2;
//    static ImageView simg3;
//    static ImageView timg1;
//    static ImageView timg2;
//    static ImageView timg3;
//
//        LinearLayout linear1 , linear2;
//        TextView txt1 ,txt2;

//
//        fimg1 = findViewById(R.id.fimg1);
//        fimg2 = findViewById(R.id.fimg2);
//        fimg3 = findViewById(R.id.fimg3);
//        simg1 = findViewById(R.id.simg1);
//        simg2 = findViewById(R.id.simg2);
//        simg3 = findViewById(R.id.simg3);
//        timg1 = findViewById(R.id.timg1);
//        timg2 = findViewById(R.id.timg2);
//        timg3 = findViewById(R.id.timg3);
//        linear1 = findViewById(R.id.linear1);
//        linear2 = findViewById(R.id.linear2);
//        txt1 = findViewById(R.id.txt1);
//        txt2 = findViewById(R.id.txt2);
//
//        combinationlist.add(new int[]{0,1,2});
//        combinationlist.add(new int[]{3,4,5});
//        combinationlist.add(new int[]{6,7,8});
//        combinationlist.add(new int[]{0,3,6});
//        combinationlist.add(new int[]{1,4,7});
//        combinationlist.add(new int[]{2,5,8});
//        combinationlist.add(new int[]{2,4,6});
//        combinationlist.add(new int[]{0,4,8});
//
//        String player1 = getIntent().getStringExtra("player1");
//        String player2 = getIntent().getStringExtra("player2");
//        txt1.setText(player1);
//        txt2.setText(player2);
//
//        fimg1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                if (isboxselected(0))
//                {
//                    performaction(fimg1,0);
//
//                }
//            }
//        });
//
//        fimg2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                if (isboxselected(1))
//                {
//                    performaction(fimg2,2);
//                }
//            }
//        });
//
//        fimg3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                if (isboxselected(2))
//                {
//                    performaction(fimg3,3);
//                }
//
//            }
//        });
//
//        simg1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                if (isboxselected(3))
//                {
//                    performaction(simg1,4);
//                }
//            }
//        });
//
//        simg2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                if (isboxselected(4))
//                {
//                    performaction(simg2,4);
//                }
//            }
//        });
//
//        simg3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                if (isboxselected(5))
//                {
//                    performaction(simg3,5);
//                }
//            }
//        });
//
//        timg1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                if (isboxselected(6))
//                {
//                    performaction(timg1,6);
//                }
//            }
//        });
//
//        timg2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                if (isboxselected(7))
//                {
//                    performaction(timg2,7);
//                }
//            }
//        });
//
//        timg3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                if (isboxselected(8))
//                {
//                    performaction(timg3,8);
//                }
//            }
//        });
//
//    }
//
//    private void performaction(ImageView img,int selectedboxposition)
//    {
//        boxposition[selectedboxposition] = playerturn;
//
//        if (playerturn == 1)
//        {
//           img.setImageResource(R.drawable.lettero);
//           if (checkwinner())
//           {
//               Windialog windialog = new Windialog(gamepage.this, txt1.getText().toString()+" has won the match ",gamepage.this);
//               windialog.setCancelable(false);
//               windialog.show();
//           }
//           else if(totelselectedbox == 9)
//           {
//               Windialog windialog = new Windialog(gamepage.this, " it's draw match " ,gamepage.this);
//               windialog.setCancelable(false);
//               windialog.show();
//           }
//
//           else
//           {
//               changeplayerTurn(2);
//
//               totelselectedbox++;
//           }
//        }
//
//
//        else
//        {
//            img.setImageResource(R.drawable.lettero);
//            if (checkwinner())
//            {
//                Windialog windialog = new Windialog(gamepage.this, txt2.getText().toString()+" has won the match ",gamepage.this);
//                windialog.setCancelable(false);
//                windialog.show();
//            }
//            else if(selectedboxposition == 9)
//            {
//                Windialog windialog = new Windialog(gamepage.this, " it's draw match " ,gamepage.this);
//                windialog.setCancelable(false);
//                windialog.show();
//            }
//            else
//            {
//                changeplayerTurn(1);
//                totelselectedbox++;
//            }
//        }
//    }
//
//
//
//    private void changeplayerTurn(int currentPlayerTurn)
//    {
//        playerturn = currentPlayerTurn;
//
//        if(playerturn == 1)
//        {
//            txt1.setBackgroundResource(R.drawable.layoutbg);
//            txt2.setBackgroundResource(R.drawable.layoutbg);
//        }
//        else
//        {
//            txt2.setBackgroundResource(R.drawable.layoutbg);
//            txt1.setBackgroundResource(R.drawable.layoutbg);
//        }
//
//    }
//
//    private boolean checkwinner() {
//        boolean winner = false;
//        for (int i = 0; i < combinationlist.size(); i++) {
//            int[] combination = combinationlist.get(i);
//            if (boxposition[combination[0]] != 0 && boxposition[combination[0]] == boxposition[combination[1]] && boxposition[combination[1]] == boxposition[combination[2]]) {
//                if (boxposition[combination[0]] == 1) {
//                    winner = true;
//                } else {
//                    winner = false;
//                }
//            }
//        }
//        return winner;
//    }
//
//    private boolean isboxselected(int position) {
//
//        if (boxposition[position] == 0) {
//            return false;
//        } else {
//            return true;
//            }
//    }

//
//}
//




