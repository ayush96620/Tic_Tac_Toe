package com.example.tic_tac_toe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class addPlayer extends AppCompatActivity {

    TextView txt1 , txt2;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_player);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
            });


        txt1 = findViewById(R.id.txt1);
        txt2 = findViewById(R.id.txt2);
        btn = findViewById(R.id.btn);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String s1 = txt1.getText().toString();
                String s2 = txt2.getText().toString();

                if (s1.isEmpty() || s2.isEmpty())
                {
                    Toast.makeText(addPlayer.this, "Please enter details", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Intent i = new Intent(addPlayer.this, gamepage.class);
                    i.putExtra("name1", s1);
                    i.putExtra("name2", s2);
                    startActivity(i);
                    finish();
                }
            }
        });
    }
}